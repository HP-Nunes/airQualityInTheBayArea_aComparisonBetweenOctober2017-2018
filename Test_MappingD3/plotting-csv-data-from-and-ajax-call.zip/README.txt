A Pen created at CodePen.io. You can find this one at https://codepen.io/plotly/pen/eNaErL.

 

Forked from [Plotly](http://codepen.io/plotly/)'s Pen [ZGPEqR](http://codepen.io/plotly/pen/ZGPEqR/).